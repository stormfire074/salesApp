﻿// Decompiled with JetBrains decompiler
// Type: Sysinfocus.AspNetCore.Components.BarcodeFormat
// Assembly: Sysinfocus.AspNetCore.Components, Version=0.0.1.9, Culture=neutral, PublicKeyToken=null
// MVID: 0600E25E-71A8-4862-A214-F603368A4A0E
// Assembly location: C:\Users\SyedShoaibAliShah\OneDrive - Axelliant, LLC\Documents\Sysinfocus.AspNetCore.Components.dll

#nullable disable
namespace Sysinfocus.AspNetCore.Components
{
  public enum BarcodeFormat
  {
    Code128,
    Code39,
    EAN13,
    EAN8,
    EAN5,
    EAN2,
    UPC,
    ITF14,
    MSI,
    MSI10,
    MSI11,
    MSI1010,
    MSI1110,
    Pharmacode,
    Codabar,
  }
}
