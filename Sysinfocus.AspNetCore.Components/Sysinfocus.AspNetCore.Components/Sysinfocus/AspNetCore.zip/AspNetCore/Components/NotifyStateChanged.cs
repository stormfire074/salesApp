﻿// Decompiled with JetBrains decompiler
// Type: Sysinfocus.AspNetCore.Components.NotifyStateChanged
// Assembly: Sysinfocus.AspNetCore.Components, Version=0.0.1.9, Culture=neutral, PublicKeyToken=null
// MVID: 0600E25E-71A8-4862-A214-F603368A4A0E
// Assembly location: C:\Users\SyedShoaibAliShah\OneDrive - Axelliant, LLC\Documents\Sysinfocus.AspNetCore.Components.dll

#nullable enable
namespace Sysinfocus.AspNetCore.Components
{
  public delegate void NotifyStateChanged(object sender, object state);
}
